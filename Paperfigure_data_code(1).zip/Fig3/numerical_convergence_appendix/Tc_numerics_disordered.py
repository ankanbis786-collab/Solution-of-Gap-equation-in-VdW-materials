import numpy as np
import matplotlib.pyplot as plt

# Replace 'data.dat' with the path to your file
filename = "eigendata_Tvsm2_625_dis_kf59_numerics_without2.dat"

# Load data, skipping the first row (header)
data = np.loadtxt(filename, skiprows=1)

# Assuming first column is x, second column is y
x = data[:, 0]
y = data[:, 1]

# Plot
plt.figure(figsize=(9,7))
plt.plot(x, y, marker='o', linestyle='-', linewidth=2, markersize=6)

# Set log-log scale
#plt.xscale("log")
#plt.yscale("log")

# Axis labels with larger font size
plt.xlabel(r"$q_{Max}$ (K)", fontsize=36)
plt.ylabel(r"$T_c$ (K)", fontsize=36)

# Increase tick label size
plt.tick_params(axis='both', which='major', labelsize=18)

# Title
#plt.title(r"Ordered state", fontsize=18)

plt.tight_layout()
plt.savefig("Tcvsqmax.pdf")
plt.show()

