import numpy as np
import matplotlib.pyplot as plt

# Map each file to its lambda value
files = {
    "int_dq0__ordered_3.dat": 3,
   # "int_dq0__ordered_10.dat": 10,
    "int_dq0__ordered_20.dat": 20,
   # "int_dq0__ordered_50.dat": 50,
    "int_dq0__ordered_100.dat": 100
}

# Marker styles to help differentiate
markers = ["o", "s", "D", "^", "v"]  

plt.figure(figsize=(9,7))

for (fname, lam), marker in zip(files.items(), markers):
    # Load data (skip header starting with '#')
    data = np.loadtxt(fname, comments="#")
    q0 = data[:,0]    # first column
    dq0 = data[:,1]   # second column
    
    # Now label only with the number
    plt.plot(
        q0, dq0, 
        marker=marker, linestyle="-", linewidth=1.5, markersize=6,
        label=f"{lam}"
    )

# Set both axes to log scale
plt.xscale("log")
plt.yscale("log")

# Bigger tick numbers
plt.tick_params(axis="both", which="major", labelsize=18)

plt.xlabel(r"$q_0$ (K)", fontsize=30)
plt.ylabel(r"$d(q_0)$", fontsize=30)

# Legend with title
plt.legend(title=r"$\Lambda/k_a$", fontsize=18, title_fontsize=20)

plt.tight_layout()

# --- save figure as PDF ---
plt.savefig("d(q0)_ordered_loglog.pdf", format="pdf")

plt.show()

